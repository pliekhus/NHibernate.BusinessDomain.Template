﻿using FluentNHibernate.Cfg;
using FluentNHibernate.Cfg.Db;
using NHibernate;
using NHibernate.Dialect;
using NHibernate.SessionFactory.Helpers;
using System.Configuration;

namespace $safeprojectname$
{
	public class SessionFactory : BaseSessionFactory
	{
		public override ISessionFactory CreateSessionFactory(string connectionStringKey)
		{
			return Fluently.Configure()
				//uncomment the line below and point it to one of your maps
				//.Mappings(m => m.FluentMappings.AddFromAssemblyOf<BusinessObjectMap>())
				.Database(MsSqlConfiguration.MsSql2012.Dialect<MsSqlAzure2008Dialect>()
					.ConnectionString(ConfigurationManager.ConnectionStrings[connectionStringKey].ConnectionString))
				.BuildSessionFactory();
		}
	}
}