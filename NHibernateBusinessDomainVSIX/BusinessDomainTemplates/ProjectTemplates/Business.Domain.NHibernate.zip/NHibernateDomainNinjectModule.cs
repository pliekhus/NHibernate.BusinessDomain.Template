﻿using Business.Domain.Interfaces;
using Ninject.Modules;

namespace $safeprojectname$
{
	public class NHibernateDomainNinjectModule : NinjectModule
	{
		public override void Load()
		{
			Bind<IDomainRepository>().To<NHibernateDomainRepository>();
		}
	}
}