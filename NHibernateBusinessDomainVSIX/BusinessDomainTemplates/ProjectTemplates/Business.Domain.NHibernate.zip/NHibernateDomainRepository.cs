﻿using Business.Domain.Interfaces;

namespace $safeprojectname$
{
	public class NHibernateDomainRepository : IDomainRepository
	{
	}
}